﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Ahad_Project.Models
{
    public partial class Department
    {
        public Department()
        {
            Employee = new HashSet<Employee>();
            Vacancy = new HashSet<Vacancy>();
        }

        public byte Id { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }

        public virtual ICollection<Employee> Employee { get; set; }
        public virtual ICollection<Vacancy> Vacancy { get; set; }
    }
}
