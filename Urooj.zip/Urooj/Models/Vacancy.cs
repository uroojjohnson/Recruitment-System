﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Ahad_Project.Models
{
    public partial class Vacancy
    {
        public Vacancy()
        {
            Interviews = new HashSet<Interviews>();
        }

        public int Id { get; set; }
        public DateTime UploadDate { get; set; }
        public DateTime LastDate { get; set; }
        public byte DepId { get; set; }

        public virtual Department Dep { get; set; }
        public virtual ICollection<Interviews> Interviews { get; set; }
    }
}
