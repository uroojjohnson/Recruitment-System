﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Ahad_Project.Models
{
    public partial class Employee
    {
        public Employee()
        {
            InterviewsInterviewerOneNavigation = new HashSet<Interviews>();
            InterviewsInterviewerThreeNavigation = new HashSet<Interviews>();
            InterviewsInterviewerTwoNavigation = new HashSet<Interviews>();
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool Gender { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public byte? DepartmentId { get; set; }

        public virtual Department Department { get; set; }
        public virtual ICollection<Interviews> InterviewsInterviewerOneNavigation { get; set; }
        public virtual ICollection<Interviews> InterviewsInterviewerThreeNavigation { get; set; }
        public virtual ICollection<Interviews> InterviewsInterviewerTwoNavigation { get; set; }
    }
}
