﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Ahad_Project.Models
{
    public partial class Interviews
    {
        public Interviews()
        {
            Schedule = new HashSet<Schedule>();
        }

        public byte Id { get; set; }
        public int VacId { get; set; }
        public int InterviewerOne { get; set; }
        public int? InterviewerTwo { get; set; }
        public int? InterviewerThree { get; set; }

        public virtual Employee InterviewerOneNavigation { get; set; }
        public virtual Employee InterviewerThreeNavigation { get; set; }
        public virtual Employee InterviewerTwoNavigation { get; set; }
        public virtual Vacancy Vac { get; set; }
        public virtual ICollection<Schedule> Schedule { get; set; }
    }
}
