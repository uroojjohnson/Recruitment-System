﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ahad_Project.Models;

namespace Ahad_Project.Controllers
{
    public class InterviewsController : Controller
    {
        private readonly RecruitmentDBContext _context;

        public InterviewsController(RecruitmentDBContext context)
        {
            _context = context;
        }

        // GET: Interviews
        public async Task<IActionResult> Index()
        {
            var recruitmentDBContext = _context.Interviews.Include(i => i.InterviewerOneNavigation).Include(i => i.InterviewerThreeNavigation).Include(i => i.InterviewerTwoNavigation).Include(i => i.Vac);
            return View(await recruitmentDBContext.ToListAsync());
        }

        // GET: Interviews/Details/5
        public async Task<IActionResult> Details(byte? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var interviews = await _context.Interviews
                .Include(i => i.InterviewerOneNavigation)
                .Include(i => i.InterviewerThreeNavigation)
                .Include(i => i.InterviewerTwoNavigation)
                .Include(i => i.Vac)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (interviews == null)
            {
                return NotFound();
            }

            return View(interviews);
        }

        // GET: Interviews/Create
        public IActionResult Create()
        {
            ViewData["InterviewerOne"] = new SelectList(_context.Employee, "Id", "Contact");
            ViewData["InterviewerThree"] = new SelectList(_context.Employee, "Id", "Contact");
            ViewData["InterviewerTwo"] = new SelectList(_context.Employee, "Id", "Contact");
            ViewData["VacId"] = new SelectList(_context.Vacancy, "Id", "Id");
            return View();
        }

        // POST: Interviews/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,VacId,InterviewerOne,InterviewerTwo,InterviewerThree")] Interviews interviews)
        {
            if (ModelState.IsValid)
            {
                _context.Add(interviews);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["InterviewerOne"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerOne);
            ViewData["InterviewerThree"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerThree);
            ViewData["InterviewerTwo"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerTwo);
            ViewData["VacId"] = new SelectList(_context.Vacancy, "Id", "Id", interviews.VacId);
            return View(interviews);
        }

        // GET: Interviews/Edit/5
        public async Task<IActionResult> Edit(byte? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var interviews = await _context.Interviews.FindAsync(id);
            if (interviews == null)
            {
                return NotFound();
            }
            ViewData["InterviewerOne"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerOne);
            ViewData["InterviewerThree"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerThree);
            ViewData["InterviewerTwo"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerTwo);
            ViewData["VacId"] = new SelectList(_context.Vacancy, "Id", "Id", interviews.VacId);
            return View(interviews);
        }

        // POST: Interviews/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(byte id, [Bind("Id,VacId,InterviewerOne,InterviewerTwo,InterviewerThree")] Interviews interviews)
        {
            if (id != interviews.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(interviews);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!InterviewsExists(interviews.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["InterviewerOne"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerOne);
            ViewData["InterviewerThree"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerThree);
            ViewData["InterviewerTwo"] = new SelectList(_context.Employee, "Id", "Contact", interviews.InterviewerTwo);
            ViewData["VacId"] = new SelectList(_context.Vacancy, "Id", "Id", interviews.VacId);
            return View(interviews);
        }

        // GET: Interviews/Delete/5
        public async Task<IActionResult> Delete(byte? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var interviews = await _context.Interviews
                .Include(i => i.InterviewerOneNavigation)
                .Include(i => i.InterviewerThreeNavigation)
                .Include(i => i.InterviewerTwoNavigation)
                .Include(i => i.Vac)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (interviews == null)
            {
                return NotFound();
            }

            return View(interviews);
        }

        // POST: Interviews/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(byte id)
        {
            var interviews = await _context.Interviews.FindAsync(id);
            _context.Interviews.Remove(interviews);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool InterviewsExists(byte id)
        {
            return _context.Interviews.Any(e => e.Id == id);
        }
    }
}
